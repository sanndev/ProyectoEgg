package EggAdopcionMascotas.AppAdopcionMascotas.Errores;

public class ErroresServicio extends Exception {

    public ErroresServicio(String mensaje) {
        super(mensaje);
    }

}
