package EggAdopcionMascotas.AppAdopcionMascotas.Repositorios;

import EggAdopcionMascotas.AppAdopcionMascotas.Entidades.Zona;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ZonaRepositorio extends JpaRepository<Zona, String> {

}
